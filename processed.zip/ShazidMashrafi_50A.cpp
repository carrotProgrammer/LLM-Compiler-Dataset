#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n,m,d;
    cin>>n>>m;
    d=(n*m)/2;
    cout<<d<<endl;
}