#include <iostream>
using namespace std;

int main() {
  int n;
  cin >> n;
  cout << (n - 1) / 2 << endl;
  return 0;
}
