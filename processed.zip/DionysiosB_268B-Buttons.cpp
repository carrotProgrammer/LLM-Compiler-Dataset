#include <cstdio>

int main(){
    unsigned long long n; scanf("%lld", &n);
    printf("%lld\n", n * (n*n + 5)/ 6);
    return 0;
}
