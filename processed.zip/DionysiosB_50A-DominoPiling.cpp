#include <cstdio>
using namespace std;

int main(){
    int M = 0, N = 0; scanf("%d %d\n",&M, &N);
    printf("%d\n", M * N / 2);
    return 0;
}
