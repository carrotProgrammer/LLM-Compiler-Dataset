#include <cstdio>
int main(){int n; scanf("%d", &n);printf("%d\n", 3 * n / 2);return 0;}
