#include <cstdio>

int main(){

    int a(0), b(0); scanf("%d %d\n", &a, &b);
    printf("%d\n", a + b);

    return 0;
}
