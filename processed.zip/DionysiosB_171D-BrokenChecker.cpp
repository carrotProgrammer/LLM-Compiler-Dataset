#include <cstdio>
#include <iostream>

int main(){

    std::string output("023121");
    int n(0); scanf("%d", &n);
    printf("%c\n", output[n]);

    return 0;
}
