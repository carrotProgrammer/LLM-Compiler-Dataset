#include <cstdio>

int main(){

    puts("FORTRAN 77");

    return 0;
}
