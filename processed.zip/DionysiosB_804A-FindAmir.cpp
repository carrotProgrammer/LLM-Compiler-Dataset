#include <cstdio>

int main(){

    long n; scanf("%ld", &n);
    printf("%ld\n", (n - 1) / 2);
    
    return 0;
}
