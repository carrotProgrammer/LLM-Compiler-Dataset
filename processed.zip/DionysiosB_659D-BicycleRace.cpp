#include <iostream>

int main(){

    long n; std::cin >> n;
    std::cout << ((n - 4) / 2) << std::endl;

    return 0;
}
