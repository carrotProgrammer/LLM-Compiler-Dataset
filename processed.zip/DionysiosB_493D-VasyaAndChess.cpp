#include <cstdio>

int main(){

    long n; scanf("%ld\n", &n);
    if(n % 2){puts("black");}
    else{puts("white\n1 2");}

    return 0;
}
