#include <cstdio>

int main(){

    int n1, n2, k1, k2; scanf("%d %d %d %d\n", &n1, &n2, &k1, &k2);
    puts(n1 > n2 ? "First" : "Second");

    return 0;
}
