#include <iostream>

int main(){

    int64_t n; std::cin >> n;
    int64_t res = 3 * n * (n + 1) + 1;
    std::cout << res << std::endl;

    return 0;
}
