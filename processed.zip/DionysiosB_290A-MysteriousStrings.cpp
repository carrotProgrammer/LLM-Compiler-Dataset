#include <cstdio>
int main(){
    int a(0); scanf("%d", &a);
    if(a == 1)  {printf("Washington\n");}
    if(a == 2)  {printf("Adams\n");}
    if(a == 3)  {printf("Jefferson\n");}
    if(a == 4)  {printf("Madison\n");}
    if(a == 5)  {printf("Monroe\n");}
    if(a == 6)  {printf("Adams\n");}
    if(a == 7)  {printf("Jackson\n");}
    if(a == 8)  {printf("Van Buren\n");}
    if(a == 9)  {printf("Harrison\n");}
    if(a == 10) {printf("Tyler\n");}
    if(a == 11) {printf("Polk\n");}
    if(a == 12) {printf("Taylor\n");}
    if(a == 13) {printf("Fillmore\n");}
    if(a == 14) {printf("Pierce\n");}
    if(a == 15) {printf("Buchanan\n");}
    if(a == 16) {printf("Lincoln\n");}
    if(a == 17) {printf("Johnson\n");}
    if(a == 18) {printf("Grant\n");}
    if(a == 19) {printf("Hayes\n");}
    if(a == 20) {printf("Garfield\n");}
    if(a == 21) {printf("Arthur\n");}
    if(a == 22) {printf("Cleveland\n");}
    if(a == 23) {printf("Harrison\n");}
    if(a == 24) {printf("Cleveland\n");}
    if(a == 25) {printf("McKinley\n");}
    if(a == 26) {printf("Roosevelt\n");}
    if(a == 27) {printf("Taft\n");}
    if(a == 28) {printf("Wilson\n");}
    if(a == 29) {printf("Harding\n");}
    if(a == 30) {printf("Coolidge\n");}
    if(a == 31) {printf("Hoover\n");}
    if(a == 32) {printf("Roosevelt\n");}
    if(a == 33) {printf("Truman\n");}
    if(a == 34){printf("Eisenhower\n");}
    if(a == 35){printf("Kennedy\n");}
    if(a == 36){printf("Johnson\n");}
    if(a == 37){printf("Nixon\n");}
    if(a == 38){printf("Ford\n");}
    if(a == 39){printf("Carter\n");}
    if(a == 40){printf("Reagan\n");}
    
    return 0;
}
