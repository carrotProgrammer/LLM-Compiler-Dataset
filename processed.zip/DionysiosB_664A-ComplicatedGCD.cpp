#include <iostream>

int main(){

    std::string a, b; std::cin >> a >> b;
    std::cout << (a == b ? a : "1") << std::endl;

    return 0;
}
