#include <cstdio>

int main(){
    puts("25");
    return 0;
}
