#include <cstdio>

int main(){

    int input(0); scanf("%d\n", &input);

    if(input == 1){puts("1");}
    else if(input == 1){puts("1");}
    else if(input == 2){puts("0");}
    else if(input == 3){puts("0");}
    else if(input == 4){puts("1");}
    else if(input == 5){puts("0");}
    else if(input == 6){puts("1");}
    else if(input == 7){puts("0");}
    else if(input == 8){puts("1");}
    else if(input == 9){puts("1");}
    else if(input == 10){puts("1");}
    else if(input == 11){puts("0");}
    else if(input == 12){puts("0");}
    else if(input == 13){puts("1");}
    else if(input == 14){puts("0");}
    else if(input == 15){puts("1");}
    else if(input == 16){puts("0");}
    else{puts("ERROR");}

    return 0;
}
