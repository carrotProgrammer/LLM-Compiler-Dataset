#include<bits/stdc++.h>
using namespace std;

int main()
{
    char ch,s[1000];
    cin>>s;
    s[0]=toupper(s[0]);
    cout<<s<<endl;
}