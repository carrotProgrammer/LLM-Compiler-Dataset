#include <cstdio>

int main(){

    long long n; scanf("%lld\n", &n);
    puts(n % 2 ? "1" : "2");

    return 0;
}
