#include <cstdio>

int main(){

    long long n(0); scanf("%lld", &n);
    printf("%lld\n", 6 * n * (n - 1) + 1);

    return 0;
}
