#include <cstdio>

int main(){

    int n; scanf("%d", &n);
    puts((n % 2) ? "contest" : "home");

    return 0;
}
